# pyhelloworld3

Smallest package ever.

Useful for testing automated package management.

Useless for everything else.

# Forked form [https://github.com/jripsl/pyhelloworld](https://github.com/jripsl/pyhelloworld)

Added Python 3 support. Removed everything else.
