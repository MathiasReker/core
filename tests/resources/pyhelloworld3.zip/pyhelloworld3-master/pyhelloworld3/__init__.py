"""
pyhelloworld3

Smallest package ever.

Useful for testing automated package management.

Useless for everything else.
"""

__version__ = '1.0.0'

from .helloworld import hello_world
